# Software FAQs

## Can other operating systems besides Ubuntu and windows be used?

We have only tested on Ubuntu　and windows which means it's the only operating system we currently officially support. Users are always welcome to try different operating systems and can share their patches with the community if they are successfully able to use them.

---
## Can other Languages besides C/C++,Python, C# be used?

We have only tested on C/C++, Python,C# which means it's the only Languages we currently officially support. Users are always welcome to try different Languages through swig and can share their patches with the community if they are successfully able to use them.

---
**More Software FAQs to follow.**
